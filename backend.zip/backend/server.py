from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

mongo_url = os.environ.get("MONGO_URL", "mongodb://localhost:27017")
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ.get("DB_NAME", "novapixl")]

app = FastAPI()
api_router = APIRouter(prefix="/api")


class SponsorshipCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    brand: Optional[str] = Field(default="", max_length=200)
    budget: Optional[str] = Field(default="", max_length=80)
    message: str = Field(min_length=1, max_length=2000)


class Sponsorship(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: str
    brand: Optional[str] = ""
    budget: Optional[str] = ""
    message: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class ChannelStats(BaseModel):
    subscribers: int
    total_views: int
    videos: int
    channel_handle: str
    channel_name: str
    country: str = "India"
    joined: str = "November 22, 2024"


@api_router.get("/")
async def root():
    return {"message": "NovaPixl API online", "status": "ok"}


@api_router.get("/channel/stats", response_model=ChannelStats)
async def get_channel_stats():
    return ChannelStats(
        subscribers=626,
        total_views=66568,
        videos=14,
        channel_handle="@NovaPixl",
        channel_name="NovaPixl",
        country="India",
        joined="November 22, 2024",
    )


@api_router.post("/sponsorship", response_model=Sponsorship, status_code=201)
async def create_sponsorship(payload: SponsorshipCreate):
    inquiry = Sponsorship(**payload.model_dump())
    doc = inquiry.model_dump()
    doc["created_at"] = doc["created_at"].isoformat()
    await db.sponsorships.insert_one(doc)
    return inquiry


@api_router.get("/sponsorship", response_model=List[Sponsorship])
async def list_sponsorships():
    items = await db.sponsorships.find({}, {"_id": 0}).sort("created_at", -1).to_list(500)
    for it in items:
        if isinstance(it.get("created_at"), str):
            it["created_at"] = datetime.fromisoformat(it["created_at"])
    return items


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
